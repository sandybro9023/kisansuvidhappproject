<div id="wrapper">
    
    <ul class="sidebar navbar-nav">
        <li class="nav-item">
            <a class="nav-link" href="dashbord.php">
            <i class="ft-home iconsize"></i><span>DASHBOARD</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="users.php">
               <i class="material-icons background-round">person_outline</i><span>MANAGE USERS</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="manage_product.php">
               <i class="material-icons background-round">store</i><span>MANAGE STORE</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="offers.php">
                <img src="images/sale.png" alt="not found"> 
                <span class="mt-1">OFFERS</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="reports.php">
                <i class="ft-file iconsize"></i>
                <span class="mt-1">REPORTS</span>
            </a>
        </li>
        
       
    </ul>