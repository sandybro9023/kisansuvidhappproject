<!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.14.0/css/mdb.min.css" rel="stylesheet">
<!-- <link href="../include/mdb/css/mdb.min.css" rel="stylesheet"> -->
<link href="../include/material-design/material-components-web.min.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="../include/fonts/feather/style.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css">

<!-- MyCss -->
<link rel="stylesheet" href="css/main.css">
<!-- fonts -->
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lobster">
<link href="https://fonts.googleapis.com/css?family=Rubik:300,400,500,700,900|Montserrat:300,400,500,600,700,800,900" rel="stylesheet">
<!-- Font Awesome -->
<link href="../include/fontawesome-free-5.12.1/css/fontawesome.css" rel="stylesheet">
<link href="../include/fontawesome-free-5.12.1/css/regular.css" rel="stylesheet">
<link href="../include/fontawesome-free-5.12.1/css/brands.css" rel="stylesheet">
<link href="../include/fontawesome-free-5.12.1/css/solid.css" rel="stylesheet">
<!-- Font Google -->
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">