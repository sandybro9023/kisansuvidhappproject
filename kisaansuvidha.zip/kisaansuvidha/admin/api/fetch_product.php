<?php 
  
include('cors.php');
require('../database.php');

// Retrieve the username and password from the POST request
//$username = $_POST['username'];
//$password = $_POST['password'];

// Encrypt the password using MD5
//$encryptedPassword = md5($password);

// Query the database to check if credentials match
$sql="select product.*,categories.categories from product,categories where 
product.category_id=categories.category_id order by  product.id  asc";
$stmt = $con->prepare($sql);
//$stmt->bindParam(':username', $username);
//$stmt->bindParam(':password', $encryptedPassword);
$stmt->execute();
$result = $stmt->get_result();
$product = $result->fetch_assoc();

if ($product) {
    // Valid credentials
    $response = [
        'success' => true,
        'message' => 'Login successful',
        'categories' => $categories['categories'],
        
        'id' => $categories['id'],
    ];
} else {
    // Invalid credentials
    $response = [
        'success' => false,
        'message' => 'Invalid username or password',
    ];
}

// Send the response as JSON
header('Content-Type: application/json');
echo json_encode($response);
?>