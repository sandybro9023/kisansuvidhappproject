<?php 
  
include('cors.php');
require('../database.php');

// Retrieve the username and password from the POST request
//$username = $_POST['username'];
//$password = $_POST['password'];

// Encrypt the password using MD5
//$encryptedPassword = md5($password);

// Query the database to check if credentials match
$sql = "select * from categories ";
$stmt = $con->prepare($sql);

$stmt->execute();
$result = $stmt->get_result();
$categories = $result->fetch_assoc();

if ($categories) {
    // Valid credentials
    $response = [
        'success' => true,
        'message' => 'Login successful',
        'categories' => $categories['categories'],
        
        'category_id' => $categories['category_id'],
    ];
} else {
    // Invalid credentials
    $response = [
        'success' => false,
        'message' => 'Invalid username or password',
    ];
}

// Send the response as JSON
header('Content-Type: application/json');
echo json_encode($response);
?>