<?php

include("../database.php");
$con=database();

if(isset($_POST["name"]))
{
	$name=$_POST["name"];
}
else return;
if(isset($_POST["email"]))
{
	$email=$_POST["email"];
}
else return;
if(isset($_POST["password"]))
{
	$password=$_POST["password"];
}
else return;
if(isset($_POST["mobile"]))
{
	$mobile=$_POST["mobile"];
}
else return;

$query="INSERT INTO `users`( `name`, `email`, `password`, `mobile`) 
VALUES ('$name','$email','$password','$mobile')";
$exe=mysqli_query($con,$query);

$arr=[];
if($exe)
{
	$arr["success"]="true";
}
else
{
	$arr["sucess"]="false";
}
print(json_encode($arr));

?>