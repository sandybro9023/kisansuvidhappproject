<?php 
 
require('../database.php');
require('../functions.inc.php');

$msg='';
if(isset($_POST['login'])){
	 $email=get_safe_value($con,$_POST['email']);
	 $pass=get_safe_value($con,$_POST['pass']);
	 $sql="select * from admin_users where email='$email' and pass='$pass'";
	 $res=mysqli_query($con,$sql);
     $count=mysqli_num_rows($res);
     if($count>0){
		 $_SESSION['ADMIN_LOGIN']="yes";
		 $_SESSION['ADMIN_EMAIL']="$email";
		 header('location:dashborad.php');
		 die();
	 }else{
		 $msg="Please enter login details ";
	 }	 
	 
}




$sql = "select * from  admin_users order by aid asc";
$res = mysqli_query($con, $sql);

// Fetching all rows and storing them in an array
$data = array();
while ($row = mysqli_fetch_assoc($res)) {
    $data[] = $row;
}
$returnData = array(
	'flag' => 1,
	'msg' => 'success',
	'data' => $data
);
echo json_encode($returnData);
return;
?>
